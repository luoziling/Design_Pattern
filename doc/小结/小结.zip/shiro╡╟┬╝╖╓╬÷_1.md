

1. 11f0151f-b567-4c57-a95c-5a06a1fa3b4b
2. d432af2a-384f-44dc-b96d-90397a06775d



- 授权缓存与IP相关
- 登录session 



要解决的问题

1. 切换登录用户导致用户缓存出现双重 

   切换用户需清理切换到目标用户后的缓存

2. 使用runAs和再次执行登录的区别

   观察是否会出现授权缓存增加，不增加说明更合适

   使用runas 应该不会增加缓存？尝试调用+判断

   会产生缓存

3. 以session作为用户登录+鉴权凭证，那么切换身份就不会对权限产生影响

   希望看到的场面：用户身份切换，session不会增加，只不过session缓存的用户信息更换，授权不会增加，只会被清理后重新授权，授权应该与认证绑定

4. shiro登录首先获取subject 如果subject不存在则构建一个并与线程绑定

5. 验证一下，切换身份并不会带来授权信息的增加，不会出现同样的授权信息，

6. 





shiro验权逻辑

最终通过PermissionAnnotationHandler对@RequirePermission进行鉴权

1. 获取当前登录用户（与会话线程绑定）

2. 调用`subject.checkPermission(perms[0]);`进行权限验证

   

3. `securityManager.checkPermission(getPrincipals(), permission);`

4. `AuthorizingSecurityManager # this.authorizer.checkPermission(principals, permission);`

   string的permission被转换成Permission对象

   

5. `AuthorizationInfo info = getAuthorizationInfo(principal);`获取用户授权，根据用户principal获取用户授权

6. 在dev环境调试，猜想：根据用户principal则是根据登录时的username也就是用户信息去判断授权，所以切换用户需删除的是切换后用户的授权信息

   不建议切换用户，会导致目标用户权限丧失重新授权，但这样可避免双重授权导致的bug

7. cache中的授权信息的key是principal

   并不是principal（简单的用户信息）而是一个Object携带用户登录信息及切换信息

   但是get获取的就是根据用户信息来的

   自己新建的principal对象无法删除

8. 不管如何，登录后删除已有授权信息，可解决授权冲突

9. shiro执行subject.login方法会自动清除Runas信息`clearRunAsIdentitiesInternal`

10. 用户身份切换，并没有清空原有用户的授权信息，此时再次且回某个用户造成两个权限







key

两次principal对象不同 导致无法删除之前的



出现bug，两个相同principal构成的key一个都无法删除

此时手动删除一个

切换身份等同于同一个会话下的身份切换而不是二次登录，重复登录导致出现多个相同授权









ThreadLocal 通过`ThreadLocalMap`来构建线程私有，ThreadLocalMap中通过弱引用避免内存泄漏`static class Entry extends WeakReference<ThreadLocal<?>>`





调用链

1. PermissionAnnotationHandler
2. AuthorizingAnnotationMethodInterceptor
3. AnnotationsAuthorizingMethodInterceptor
4. AuthorizingMethodInterceptor
5. AuthorizingSecurityManager#checkPermission
6. AuthorizingRealm#getAuthorizationInfo 获取授权信息